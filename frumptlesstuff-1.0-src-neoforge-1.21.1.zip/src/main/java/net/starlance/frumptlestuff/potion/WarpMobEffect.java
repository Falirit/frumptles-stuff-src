package net.starlance.frumptlestuff.potion;

import net.starlance.frumptlestuff.procedures.WarpOnEntityHurtProcedure;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.damagesource.DamageSource;

public class WarpMobEffect extends MobEffect {
	public WarpMobEffect() {
		super(MobEffectCategory.NEUTRAL, -15041418);
	}

	@Override
	public void onMobHurt(LivingEntity entity, int amplifier, DamageSource damagesource, float damage) {
		WarpOnEntityHurtProcedure.execute(entity.level(), entity.getX(), entity.getY(), entity.getZ(), entity);
	}
}