/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.starlance.frumptlestuff.init;

import net.starlance.frumptlestuff.item.WarperItem;
import net.starlance.frumptlestuff.item.WarpedWartItem;
import net.starlance.frumptlestuff.item.WarpedArmorTrimItem;
import net.starlance.frumptlestuff.item.WarpCrystalItem;
import net.starlance.frumptlestuff.item.ShroomlightItem;
import net.starlance.frumptlestuff.item.ReachWandItem;
import net.starlance.frumptlestuff.item.NetherCombinationSmithingTemplateItem;
import net.starlance.frumptlestuff.item.MirrorWandItem;
import net.starlance.frumptlestuff.item.MirrorShardItem;
import net.starlance.frumptlestuff.item.CrimsonShardItem;
import net.starlance.frumptlestuff.item.CrimsonArmorTrimItem;
import net.starlance.frumptlestuff.item.CombinedArmorTrimItem;
import net.starlance.frumptlestuff.item.AmethystRodItem;
import net.starlance.frumptlestuff.FstuffMod;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

public class FstuffModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(FstuffMod.MODID);
	public static final DeferredItem<Item> CRIMSON_GROWTH = block(FstuffModBlocks.CRIMSON_GROWTH);
	public static final DeferredItem<Item> WARPED_GROWTH = block(FstuffModBlocks.WARPED_GROWTH);
	public static final DeferredItem<Item> CRIMSON_SHROOMLIGHTS = block(FstuffModBlocks.CRIMSON_SHROOMLIGHTS);
	public static final DeferredItem<Item> WARPED_SHROOMLIGHTS = block(FstuffModBlocks.WARPED_SHROOMLIGHTS);
	public static final DeferredItem<Item> SHROOMLIGHT = REGISTRY.register("shroomlight", ShroomlightItem::new);
	public static final DeferredItem<Item> WARPED_WART = REGISTRY.register("warped_wart", WarpedWartItem::new);
	public static final DeferredItem<Item> WARPED_WART_STAGE_0 = block(FstuffModBlocks.WARPED_WART_STAGE_0);
	public static final DeferredItem<Item> WARPED_WART_STAGE_1 = block(FstuffModBlocks.WARPED_WART_STAGE_1);
	public static final DeferredItem<Item> WARPED_WART_STAGE_2 = block(FstuffModBlocks.WARPED_WART_STAGE_2);
	public static final DeferredItem<Item> WARP_SHARD = REGISTRY.register("warp_shard", WarpCrystalItem::new);
	public static final DeferredItem<Item> WARPER = REGISTRY.register("warper", WarperItem::new);
	public static final DeferredItem<Item> AMETHYST_ROD = REGISTRY.register("amethyst_rod", AmethystRodItem::new);
	public static final DeferredItem<Item> CRIMSON_SHARD = REGISTRY.register("crimson_shard", CrimsonShardItem::new);
	public static final DeferredItem<Item> REACH_WAND = REGISTRY.register("reach_wand", ReachWandItem::new);
	public static final DeferredItem<Item> NETHER_COMBINATION_SMITHING_TEMPLATE = REGISTRY.register("nether_combination_smithing_template", NetherCombinationSmithingTemplateItem::new);
	public static final DeferredItem<Item> MIRROR_SHARD = REGISTRY.register("mirror_shard", MirrorShardItem::new);
	public static final DeferredItem<Item> MIRROR_WAND = REGISTRY.register("mirror_wand", MirrorWandItem::new);
	public static final DeferredItem<Item> WARPED_ARMOR_TRIM_SMITHING_TEMPLATE = REGISTRY.register("warped_armor_trim_smithing_template", WarpedArmorTrimItem::new);
	public static final DeferredItem<Item> CRIMSON_ARMOR_TRIM_SMITHING_TEMPLATE = REGISTRY.register("crimson_armor_trim_smithing_template", CrimsonArmorTrimItem::new);
	public static final DeferredItem<Item> COMBINED_ARMOR_TRIM = REGISTRY.register("combined_armor_trim", CombinedArmorTrimItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}