/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.starlance.frumptlestuff.init;

import net.starlance.frumptlestuff.potion.WarpMobEffect;
import net.starlance.frumptlestuff.FstuffMod;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

public class FstuffModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, FstuffMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> WARP = REGISTRY.register("warp", () -> new WarpMobEffect());
}