/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.starlance.frumptlestuff.init;

import net.starlance.frumptlestuff.FstuffMod;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

public class FstuffModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, FstuffMod.MODID);
	public static final DeferredHolder<Potion, Potion> DARKNESS_POTION = REGISTRY.register("darkness_potion", () -> new Potion(new MobEffectInstance(MobEffects.DARKNESS, 3600, 0, false, true)));
	public static final DeferredHolder<Potion, Potion> WARP_POTION = REGISTRY.register("warp_potion", () -> new Potion(new MobEffectInstance(FstuffModMobEffects.WARP, 100, 0, false, true)));
}