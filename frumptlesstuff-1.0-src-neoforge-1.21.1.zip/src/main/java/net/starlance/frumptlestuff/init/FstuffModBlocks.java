/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.starlance.frumptlestuff.init;

import net.starlance.frumptlestuff.block.WarpedshroomlightsBlock;
import net.starlance.frumptlestuff.block.WarpedgrowthBlock;
import net.starlance.frumptlestuff.block.WarpedWartStage2Block;
import net.starlance.frumptlestuff.block.WarpedWartStage1Block;
import net.starlance.frumptlestuff.block.WarpedWartStage0Block;
import net.starlance.frumptlestuff.block.CrimsonshroomlightsBlock;
import net.starlance.frumptlestuff.block.CrimsongrowthBlock;
import net.starlance.frumptlestuff.FstuffMod;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

public class FstuffModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(FstuffMod.MODID);
	public static final DeferredBlock<Block> CRIMSON_GROWTH = REGISTRY.register("crimson_growth", CrimsongrowthBlock::new);
	public static final DeferredBlock<Block> WARPED_GROWTH = REGISTRY.register("warped_growth", WarpedgrowthBlock::new);
	public static final DeferredBlock<Block> CRIMSON_SHROOMLIGHTS = REGISTRY.register("crimson_shroomlights", CrimsonshroomlightsBlock::new);
	public static final DeferredBlock<Block> WARPED_SHROOMLIGHTS = REGISTRY.register("warped_shroomlights", WarpedshroomlightsBlock::new);
	public static final DeferredBlock<Block> WARPED_WART_STAGE_0 = REGISTRY.register("warped_wart_stage_0", WarpedWartStage0Block::new);
	public static final DeferredBlock<Block> WARPED_WART_STAGE_1 = REGISTRY.register("warped_wart_stage_1", WarpedWartStage1Block::new);
	public static final DeferredBlock<Block> WARPED_WART_STAGE_2 = REGISTRY.register("warped_wart_stage_2", WarpedWartStage2Block::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}