/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.starlance.frumptlestuff.init;

import net.starlance.frumptlestuff.FstuffMod;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class FstuffModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FstuffMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(FstuffModBlocks.CRIMSON_GROWTH.get().asItem());
			tabData.accept(FstuffModBlocks.WARPED_GROWTH.get().asItem());
			tabData.accept(FstuffModBlocks.CRIMSON_SHROOMLIGHTS.get().asItem());
			tabData.accept(FstuffModBlocks.WARPED_SHROOMLIGHTS.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(FstuffModItems.SHROOMLIGHT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(FstuffModItems.WARP_SHARD.get());
			tabData.accept(FstuffModItems.WARPER.get());
			tabData.accept(FstuffModItems.REACH_WAND.get());
			tabData.accept(FstuffModItems.MIRROR_WAND.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(FstuffModItems.WARPER.get());
			tabData.accept(FstuffModItems.REACH_WAND.get());
			tabData.accept(FstuffModItems.MIRROR_WAND.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(FstuffModItems.AMETHYST_ROD.get());
			tabData.accept(FstuffModItems.WARP_SHARD.get());
			tabData.accept(FstuffModItems.CRIMSON_SHARD.get());
			tabData.accept(FstuffModItems.MIRROR_SHARD.get());
			tabData.accept(FstuffModItems.WARPED_ARMOR_TRIM_SMITHING_TEMPLATE.get());
			tabData.accept(FstuffModItems.CRIMSON_ARMOR_TRIM_SMITHING_TEMPLATE.get());
			tabData.accept(FstuffModItems.NETHER_COMBINATION_SMITHING_TEMPLATE.get());
			tabData.accept(FstuffModItems.COMBINED_ARMOR_TRIM.get());
		}
	}
}