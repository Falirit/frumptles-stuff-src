/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.starlance.frumptlestuff.init;

import net.starlance.frumptlestuff.FstuffMod;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class FstuffModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, FstuffMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> WARP_CRYSTAL_USE = REGISTRY.register("warp_crystal_use", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("fstuff", "warp_crystal_use")));
}