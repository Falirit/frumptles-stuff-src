package net.starlance.frumptlestuff.item;

import net.minecraft.world.item.Item;

public class MirrorShardItem extends Item {
	public MirrorShardItem() {
		super(new Item.Properties());
	}
}