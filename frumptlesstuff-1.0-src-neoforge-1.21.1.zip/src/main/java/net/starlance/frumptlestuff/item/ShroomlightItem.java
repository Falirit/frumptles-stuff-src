package net.starlance.frumptlestuff.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class ShroomlightItem extends Item {
	public ShroomlightItem() {
		super(new Item.Properties().food((new FoodProperties.Builder()).nutrition(4).saturationModifier(0.3f).build()));
	}
}