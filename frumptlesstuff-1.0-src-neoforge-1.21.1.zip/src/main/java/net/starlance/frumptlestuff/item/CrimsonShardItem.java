package net.starlance.frumptlestuff.item;

import net.minecraft.world.item.Item;

public class CrimsonShardItem extends Item {
	public CrimsonShardItem() {
		super(new Item.Properties());
	}
}