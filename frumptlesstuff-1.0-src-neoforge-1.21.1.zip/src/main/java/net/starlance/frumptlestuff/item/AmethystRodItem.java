package net.starlance.frumptlestuff.item;

import net.minecraft.world.item.Item;

public class AmethystRodItem extends Item {
	public AmethystRodItem() {
		super(new Item.Properties());
	}
}