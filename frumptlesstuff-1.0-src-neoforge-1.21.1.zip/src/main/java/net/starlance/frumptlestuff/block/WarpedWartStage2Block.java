package net.starlance.frumptlestuff.block;

import net.neoforged.neoforge.common.util.DeferredSoundType;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

public class WarpedWartStage2Block extends Block {
	public WarpedWartStage2Block() {
		super(BlockBehaviour.Properties.of()
				.sound(new DeferredSoundType(1.0f, 1.0f, () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("block.nether_wart.break")), () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("block.dripstone_block.break")),
						() -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("block.dripstone_block.break")), () -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("block.dripstone_block.break")),
						() -> BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("block.dripstone_block.break"))))
				.instabreak().noCollission().noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return box(0, 0, 0, 16, 6, 16);
	}
}